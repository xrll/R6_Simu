﻿using System.Windows.Controls;

namespace R6_Simu.Domain
{
    /// <summary>
    /// Interaction logic for SampleDialog.xaml
    /// </summary>
    public partial class SampleDialog2 : UserControl
    {
        public SampleDialog2()
        {
            InitializeComponent();
        }
    }
}
