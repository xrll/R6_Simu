﻿using System.Windows.Controls;

namespace R6_Simu.Domain
{
    /// <summary>
    /// Interaction logic for SampleMessageDialog.xaml
    /// </summary>
    public partial class DelayMessageDialog: UserControl
    {
        public DelayMessageDialog()
        {
            InitializeComponent();
        }
    }
}
