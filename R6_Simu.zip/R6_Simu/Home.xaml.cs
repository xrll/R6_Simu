﻿using R6_Simu.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using Media = System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using Shaps = System.Windows.Shapes;
using MaterialDesignColors;
using MaterialDesignThemes.Wpf;
using System.Drawing.Drawing2D;
using Utilities;
using R6_Simu.Controls;
using System.Threading;
using System.Collections.ObjectModel;
using System.IO.MemoryMappedFiles;
using System.Windows.Media.Media3D;
using System.Windows.Media;
using HelixToolkit.Wpf;
using System.IO;
using System.Timers;
using System.Windows.Forms;
using System.Diagnostics;
using System.Security.Cryptography;
using Xceed.Document.NET;
using System.Drawing;
using System.Numerics;
using static System.Net.WebRequestMethods;

namespace R6_Simu
{
    /// <summary>
    /// Home.xaml 的交互逻辑
    /// </summary>
    public partial class Home : System.Windows.Controls.UserControl
    {


        bool switchingJoint = false;
        public static bool isAnimating = false;

        GeometryModel3D oldSelectedModel = null;
        string basePath = "";
        ModelVisual3D visual;
        double LearningRate = 0.02;

        Transform3DGroup F1;
        Transform3DGroup F2;
        Transform3DGroup F3;
        Transform3DGroup F4;
        Transform3DGroup F5;
        Transform3DGroup F6;
        RotateTransform3D R;
        TranslateTransform3D T;

        System.Windows.Forms.Timer timer;

        //      "T201_with_cover_v02", "V301_with_cover", "V302", "T401_with_cover", "V501_10L", "V502", "V5030" 
        Point3D center = new Point3D(); 

        public Home()
        {
            InitializeComponent();
            Loaded += Home_Loaded;
            viewPort3d.RotateGesture = new MouseGesture(MouseAction.RightClick);
            viewPort3d.PanGesture = new MouseGesture(MouseAction.LeftClick);

            //var builder = new MeshBuilder(true, true);
            //var position = new Point3D(0, 0, 0);
            //builder.AddSphere(position, 40, 20, 20);
            //geom = new GeometryModel3D(builder.ToMesh(), Materials.Brown);
            //visual = new ModelVisual3D();
            //visual.Content = geom;

            timer = new System.Windows.Forms.Timer();
            timer.Interval = 15;
            timer.Tick += new System.EventHandler(timer_Tick);
            A1 = new JointClass6((float)AD[0][0], 0, 1, 0);
            A2 = new JointClass6((float)AD[1][0], 0, 2, 0);
            A3 = new JointClass6((float)AD[2][0], 0, 3, 0);
            A4 = new JointClass6(0, (float)AD[3][1], 4, 0);
            A5 = new JointClass6(0, 0, 5, 0);
            A6 = new JointClass6((float)AD[5][0], (float)AD[5][1], 6, 0);
            wps1 = new Point3DCollection();
            wps1.Add(new Point3D(40, -70, 7));
            wps1.Add(new Point3D(40, -70, 7));
            c20.Path = wps1;

            wps2 = new Point3DCollection();
            //for (int i = 0; i <= 360; i++)
            //{
            //    double a = i / 57.29578;
            //    wps2.Add(new Point3D(10 * Math.Cos(a), 10 * Math.Sin(a), 10));
            //}
            c30.Path = wps2;
            wct = Math.Cos(cAng);
            wst = Math.Sin(cAng);

            ct = 0.866;
            st = 0.5;
            //ota2 = new double[] { -st, 0, -ct };
            //otn2 = new double[] { 0, 1, 0 };
            //oto2 = new double[] { ct, 0, -st };
            ta2 = new double[] { -st*wct, -st*wst, -ct };
            tn2 = new double[] { -wst, wct, 0 };
            to2 = new double[] { ct * wct, ct * wst, -st };
            TPoint6 = new double[] { radius * wct + 400, radius * wst + 300, 110 };
            TPoint5 = new double[] { radius * wct + 400 - pL * ta2[0], radius * wst + 300 - pL * ta2[1], 110 - pL * ta2[2] };
            TAngle5 = JointClass6.InverseCal(tn2, to2, ta2, TPoint5, AD, null);
            TAngle6 = JointClass6.InverseCal(tn2, to2, ta2, TPoint6, AD, null);


            Matrix4x4 mx = new Matrix4x4(1, 0, 0, 0, 0, (float)ct, (float)st, 0, 0, -(float)st, (float)ct, 0, 0, 0, 0, 1);
            //Matrix4x4 mz = new Matrix4x4((float)ct, -(float)st, 0, 0, (float)st, (float)ct, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
            Matrix4x4 m = mx;

            float Tz = MainWindowViewModel.Tz;
            float ntx = 400;
            float nty = -m.M22 * 100 - m.M23 * (Tz * 10 - 70);
            float ntz = -m.M32 * 100 - m.M33 * (Tz * 10 - 70) + Tz * 10;
            float mty = -m.M22 * 700 - m.M23 * (Tz * 10 - 70);
            float mtz = -m.M32 * 700 - m.M33 * (Tz * 10 - 70) + Tz * 10;

            tn1 = new double[] { 0.866, st * 0.5, ct * 0.5 };
            to1 = new double[] { 0, -ct, st };
            ta1 = new double[] { 0.5, -st * 0.866, -ct * 0.866 };
            TPoint4 = new double[] { ntx - ta1[0] * pL, nty - ta1[1] * pL, ntz - ta1[2] * pL };
            TPoint3 = new double[] { ntx, nty, ntz };
            TPoint2 = new double[] { ntx, mty, mtz };
            TPoint1 = new double[] { ntx - ta1[0] * pL, mty - ta1[1] * pL, mtz - ta1[2] * pL };

            TAngle1 = JointClass6.InverseCal(tn1, to1, ta1, TPoint1,AD,null);
            TAngle2 = JointClass6.InverseCal(tn1, to1, ta1, TPoint2, AD, null);
            TAngle3 = JointClass6.InverseCal(tn1, to1, ta1, TPoint3, AD, null);
            TAngle4 = JointClass6.InverseCal(tn1, to1, ta1, TPoint4, AD, null);

            lSPoint = new Point3D(ntx / 10,  nty/ 10, ntz / 10);
            lEPoint = new Point3D(ntx / 10, mty / 10, mtz / 10);

        }
        Point3DCollection wps1, wps2;
        double lt = 0;
        double pL = 200, wL = 600;//预位、提枪高度
        double[] tn1, to1, ta1, tn2, to2, ta2,tp2, tn3, to3, ta3, tp3, ltn3, lto3, lta3, ltp3;
        double[] TPoint1, TPoint2, TPoint3, TPoint4, TPoint5, TPoint6;
        double[] TAngle1, TAngle2, TAngle3, TAngle4, TAngle5, TAngle6;
        Point3D lSPoint, lEPoint,cSpoint;
        double radius = 100, cAng = Math.Atan2(3, 4), wAng = 0,wct=0,wst=0,ct=0,st=0;
        int Process = 0;
        private void Home_Loaded(object sender, RoutedEventArgs e)
        {
            Window? window = Window.GetWindow(this);
            var mwv = this.DataContext as MainWindowViewModel;
            mwv!.mainW = this;

        }
        public static T Clamp<T>(T value, T min, T max)
            where T : System.IComparable<T>
        {
            T result = value;
            if (value.CompareTo(max) > 0)
                result = max;
            if (value.CompareTo(min) < 0)
                result = min;
            return result;
        }

        public void Simu_Click(object sender, RoutedEventArgs e)
        {
            if (timer.Enabled)
            {
                //button.Content = "Go to position";
                isAnimating = false;
                timer.Stop();
                V6.OnJointValueChanged += Rot_OnRotValueChanged;
                //mainPara.IsEnabled = true;
            }
            else
            {
                //V6.IsEnabled = false;
                //geom.Transform = new TranslateTransform3D(reachingPoint);
                //button.Content = "STOP";
                //mainPara.IsEnabled = false;
                V6.OnJointValueChanged -= Rot_OnRotValueChanged;
                if (Process == 0)
                {
                    if (wps1.Count > 1)
                        wps1[1] = wps1[0];
                    wps2.Clear();
                }
                isAnimating = true;
                timer.Start();
            }
        }

        public void timer_Tick(object sender, EventArgs e)
        {
            Move();
        }
        int c = 0;
        private void Move()
        {
            if (Process == 0)
            {
                MainWindowViewModel.JointAngles.CopyTo(CurAngles, 0);
                bool tog = false;
                TargetAngs = TAngle1;
                double[] angles = PGInverseKinematics(TPoint1, CurAngles, ref tog);
                //MainWindowViewModel.JointAngles = new ObservableCollection<double>(angles.ToList());
                ForwardKinematics(angles);
                MainWindowViewModel.JointAngles[0] = angles[0];
                MainWindowViewModel.JointAngles[1] = angles[1];
                MainWindowViewModel.JointAngles[2] = angles[2];
                MainWindowViewModel.JointAngles[3] = angles[3];
                MainWindowViewModel.JointAngles[4] = angles[4];
                MainWindowViewModel.JointAngles[5] = angles[5];
                if (tog)
                {
                    Process = 1;
                    lt = 0;
                }
            }
            else if (Process == 1)
            {
                lt += stp * 2;
                if (lt > pL)
                {
                    if (c == 40)
                    {
                        Process = 2;
                        lt = 0;
                        c = 0;
                    }
                    c++;
                }
                else
                {
                    MainWindowViewModel.Dxyz[0] = stp * ta1[0];
                    MainWindowViewModel.Dxyz[1] = stp * ta1[1];
                    MainWindowViewModel.Dxyz[2] = stp * ta1[2];
                    MainWindowViewModel.Dxyz[3] = 0;
                    MainWindowViewModel.Dxyz[4] = 0;
                    MainWindowViewModel.Dxyz[5] = 0;
                    if (MainWindowViewModel.Jacobian[36] != 0)
                    {
                        double[] diff = JointClass6.Differential(J, new double[] { MainWindowViewModel.Dxyz[0], MainWindowViewModel.Dxyz[1], MainWindowViewModel.Dxyz[2], 0, 0, 0 });
                        MainWindowViewModel.DAngle[0] = diff[0] * 57.29578;
                        MainWindowViewModel.DAngle[1] = diff[1] * 57.29578;
                        MainWindowViewModel.DAngle[2] = diff[2] * 57.29578;
                        MainWindowViewModel.DAngle[3] = diff[3] * 57.29578;
                        MainWindowViewModel.DAngle[4] = diff[4] * 57.29578;
                        MainWindowViewModel.DAngle[5] = diff[5] * 57.29578;
                    }
                    double[] target = new double[] { TPoint1[0] + lt * ta1[0], TPoint1[1] + lt * ta1[1], TPoint1[2] + lt * ta1[2] };
                    double[] angles = JointClass6.InverseCal(tn1, to1, ta1, target, AD, MainWindowViewModel.JointAngles.ToArray());
                    ForwardKinematics(angles);
                    MainWindowViewModel.JointAngles[0] = angles[0];
                    MainWindowViewModel.JointAngles[1] = angles[1];
                    MainWindowViewModel.JointAngles[2] = angles[2];
                    MainWindowViewModel.JointAngles[3] = angles[3];
                    MainWindowViewModel.JointAngles[4] = angles[4];
                    MainWindowViewModel.JointAngles[5] = angles[5];
                }
            }
            else if (Process == 2)
            {
                lt += stp;
                if (lt > wL)
                {
                    if (c == 40)
                    {
                        Process = 3;
                        lt = 0;
                        c = 0;
                    }
                    c++;
                }
                else
                {
                    MainWindowViewModel.Dxyz[0] = -stp * to1[0];
                    MainWindowViewModel.Dxyz[1] = -stp * to1[1];
                    MainWindowViewModel.Dxyz[2] = -stp * to1[2];
                    MainWindowViewModel.Dxyz[3] = 0;
                    MainWindowViewModel.Dxyz[4] = 0;
                    MainWindowViewModel.Dxyz[5] = 0;
                    if (MainWindowViewModel.Jacobian[36] != 0)
                    {
                        double[] diff = JointClass6.Differential(J, new double[] { MainWindowViewModel.Dxyz[0], MainWindowViewModel.Dxyz[1], MainWindowViewModel.Dxyz[2], 0, 0, 0 });
                        MainWindowViewModel.DAngle[0] = diff[0] * 57.29578;
                        MainWindowViewModel.DAngle[1] = diff[1] * 57.29578;
                        MainWindowViewModel.DAngle[2] = diff[2] * 57.29578;
                        MainWindowViewModel.DAngle[3] = diff[3] * 57.29578;
                        MainWindowViewModel.DAngle[4] = diff[4] * 57.29578;
                        MainWindowViewModel.DAngle[5] = diff[5] * 57.29578;
                    }
                    double[] target = new double[] { TPoint2[0] - lt * to1[0], TPoint2[1] - lt * to1[1], TPoint2[2] - lt * to1[2] };
                    wps1[1] = new Point3D(40, -70 + lt / 10, 7);
                    double[] angles = JointClass6.InverseCal(tn1, to1, ta1, target, AD, MainWindowViewModel.JointAngles.ToArray());
                    ForwardKinematics(angles);
                    MainWindowViewModel.JointAngles[0] = angles[0];
                    MainWindowViewModel.JointAngles[1] = angles[1];
                    MainWindowViewModel.JointAngles[2] = angles[2];
                    MainWindowViewModel.JointAngles[3] = angles[3];
                    MainWindowViewModel.JointAngles[4] = angles[4];
                    MainWindowViewModel.JointAngles[5] = angles[5];
                }
            }
            else if (Process == 3)
            {
                lt += stp * 2;
                if (lt > pL / 2)
                {
                    Process = 4;
                    lt = 0;
                    fstp = true;
                }
                else
                {
                    MainWindowViewModel.Dxyz[0] = -stp * ta1[0];
                    MainWindowViewModel.Dxyz[1] = -stp * ta1[1];
                    MainWindowViewModel.Dxyz[2] = -stp * ta1[2];
                    MainWindowViewModel.Dxyz[3] = 0;
                    MainWindowViewModel.Dxyz[4] = 0;
                    MainWindowViewModel.Dxyz[5] = 0;
                    if (MainWindowViewModel.Jacobian[36] != 0)
                    {
                        double[] diff = JointClass6.Differential(J, new double[] { MainWindowViewModel.Dxyz[0], MainWindowViewModel.Dxyz[1], MainWindowViewModel.Dxyz[2], 0, 0, 0 });
                        MainWindowViewModel.DAngle[0] = diff[0] * 57.29578;
                        MainWindowViewModel.DAngle[1] = diff[1] * 57.29578;
                        MainWindowViewModel.DAngle[2] = diff[2] * 57.29578;
                        MainWindowViewModel.DAngle[3] = diff[3] * 57.29578;
                        MainWindowViewModel.DAngle[4] = diff[4] * 57.29578;
                        MainWindowViewModel.DAngle[5] = diff[5] * 57.29578;
                    }
                    double[] target = new double[] { TPoint3[0] - lt * ta1[0], TPoint3[1] - lt * ta1[1], TPoint3[2] - lt * ta1[2] };
                    double[] angles = JointClass6.InverseCal(tn1, to1, ta1, target, AD, MainWindowViewModel.JointAngles.ToArray());
                    ForwardKinematics(angles);
                    MainWindowViewModel.JointAngles[0] = angles[0];
                    MainWindowViewModel.JointAngles[1] = angles[1];
                    MainWindowViewModel.JointAngles[2] = angles[2];
                    MainWindowViewModel.JointAngles[3] = angles[3];
                    MainWindowViewModel.JointAngles[4] = angles[4];
                    MainWindowViewModel.JointAngles[5] = angles[5];
                }
            }
            else if (Process == 4)
            {
                MainWindowViewModel.JointAngles.CopyTo(CurAngles, 0);
                bool tog = false;
                TargetAngs = TAngle5;
                double[] angles = PGInverseKinematics(TPoint5, CurAngles, ref tog);
                ForwardKinematics(angles);
                MainWindowViewModel.JointAngles[0] = angles[0];
                MainWindowViewModel.JointAngles[1] = angles[1];
                MainWindowViewModel.JointAngles[2] = angles[2];
                MainWindowViewModel.JointAngles[3] = angles[3];
                MainWindowViewModel.JointAngles[4] = angles[4];
                MainWindowViewModel.JointAngles[5] = angles[5];
                if (tog)
                {
                    Process = 5;
                    lt = 0;
                }
            }
            else if (Process == 5)
            {
                lt += stp * 2;
                if (lt > pL)
                {
                    if (c == 40)
                    {
                        Process = 6;
                        lt = 0;
                        wAng = 0;
                        c = 0;
                    }
                    c++;
                }
                else
                {
                    MainWindowViewModel.Dxyz[0] = stp * ta2[0];
                    MainWindowViewModel.Dxyz[1] = stp * ta2[1];
                    MainWindowViewModel.Dxyz[2] = stp * ta2[2];
                    MainWindowViewModel.Dxyz[3] = 0;
                    MainWindowViewModel.Dxyz[4] = 0;
                    MainWindowViewModel.Dxyz[5] = 0;
                    if (MainWindowViewModel.Jacobian[36] != 0)
                    {
                        double[] diff = JointClass6.Differential(J, new double[] { MainWindowViewModel.Dxyz[0], MainWindowViewModel.Dxyz[1], MainWindowViewModel.Dxyz[2], 0, 0, 0 });
                        MainWindowViewModel.DAngle[0] = diff[0] * 57.29578;
                        MainWindowViewModel.DAngle[1] = diff[1] * 57.29578;
                        MainWindowViewModel.DAngle[2] = diff[2] * 57.29578;
                        MainWindowViewModel.DAngle[3] = diff[3] * 57.29578;
                        MainWindowViewModel.DAngle[4] = diff[4] * 57.29578;
                        MainWindowViewModel.DAngle[5] = diff[5] * 57.29578;
                    }

                    double[] target = new double[] { TPoint5[0] + lt * ta2[0], TPoint5[1] + lt * ta2[1], TPoint5[2] + lt * ta2[2] };
                    double[] angles = JointClass6.InverseCal(tn2, to2, ta2, target, AD, MainWindowViewModel.JointAngles.ToArray());
                    ForwardKinematics(angles);
                    MainWindowViewModel.JointAngles[0] = angles[0];
                    MainWindowViewModel.JointAngles[1] = angles[1];
                    MainWindowViewModel.JointAngles[2] = angles[2];
                    MainWindowViewModel.JointAngles[3] = angles[3];
                    MainWindowViewModel.JointAngles[4] = angles[4];
                    MainWindowViewModel.JointAngles[5] = angles[5];
                }
            }
            else if (Process == 6)
            {
                double cct = Math.Cos(cAng - wAng);
                double sct = Math.Sin(cAng - wAng);
                ta3 = new double[] { -st * cct, -st * sct, -ct };
                tp3 = new double[] { cct * radius + 400, sct * radius + 300, 110 };
                if (wAng < Math.PI / 2)
                {
                    tn3 = new double[] { -sct, cct, 0 };
                    to3 = new double[] { ct * cct, ct * sct, -st };
                }
                else if (wAng < Math.PI * 1.5)
                {
                    double ca = Math.Cos(wAng - Math.PI * 0.5);
                    double sa = Math.Sin(wAng - Math.PI * 0.5);

                    double[] tn = new double[] { ca, ct * sa, st * sa };
                    double[] to = new double[] { sa, -ct * ca, -st * ca };

                    double[] tn1 = new double[] { ca * ca + ct * sa * sa, -ca * sa + ct * sa * ca, st * sa };
                    double[] to1 = new double[] { ca * sa - ct * ca * sa, -sa * sa - ct * ca * ca, -st * ca };

                    tn3 = new double[] { tn1[0] * wct - tn1[1] * wst, tn1[0] * wst + tn1[1] * wct, st * sa };
                    to3 = new double[] { to1[0] * wct - to1[1] * wst, to1[0] * wst + to1[1] * wct, -st * ca };
                }
                else
                {
                    tn3 = new double[] { sct, -cct, 0 };
                    to3 = new double[] { -ct * cct, -ct * sct, st };
                }
                if(ltn3!=null&&lto3!=null&&lta3!=null)
                {
                    double d1 = tp3[0] - ltp3[0];
                    double d2 = tp3[1] - ltp3[1];
                    double d3=tp3[2] - ltp3[2];
                    double d4=ta3[0] * lto3[0] + ta3[1] * lto3[1] + ta3[2] * lto3[2];
                    double d5=tn3[0] * lta3[0] + tn3[1] * lta3[1] + tn3[2] * lta3[2];
                    double d6 = to3[0] * ltn3[0] + to3[1] * ltn3[1] + to3[2] * ltn3[2];
                    MainWindowViewModel.Dxyz[0] = d1;
                    MainWindowViewModel.Dxyz[1] = d2;
                    MainWindowViewModel.Dxyz[2] = d3;
                    MainWindowViewModel.Dxyz[3] = d4;
                    MainWindowViewModel.Dxyz[4] = d5;
                    MainWindowViewModel.Dxyz[5] = d6;
                    if (MainWindowViewModel.Jacobian[36] != 0)
                    {
                        double[] diff = JointClass6.Differential(J, new double[] { d1, d2, d3, d4, d5, d6 });
                        MainWindowViewModel.DAngle[0] = diff[0] * 57.29578;
                        MainWindowViewModel.DAngle[1] = diff[1] * 57.29578;
                        MainWindowViewModel.DAngle[2] = diff[2] * 57.29578;
                        MainWindowViewModel.DAngle[3] = diff[3] * 57.29578;
                        MainWindowViewModel.DAngle[4] = diff[4] * 57.29578;
                        MainWindowViewModel.DAngle[5] = diff[5] * 57.29578;
                    }
                }
                wps2.Add(new Point3D(cct * radius / 10, sct * radius / 10, 10));
                double[] angles = JointClass6.InverseCal(tn3, to3, ta3, tp3, AD, MainWindowViewModel.JointAngles.ToArray());
                ltn3 = tn3;
                lto3 = to3;
                lta3 = ta3;
                ltp3 = tp3;
                ForwardKinematics(angles);
                MainWindowViewModel.JointAngles[0] = angles[0];
                MainWindowViewModel.JointAngles[1] = angles[1];
                MainWindowViewModel.JointAngles[2] = angles[2];
                MainWindowViewModel.JointAngles[3] = angles[3];
                MainWindowViewModel.JointAngles[4] = angles[4];
                MainWindowViewModel.JointAngles[5] = angles[5];
                if (Math.Abs(wAng - Math.PI * 2) < 1e-4)
                {
                    if (c == 40)
                    {
                        Process = 7;
                        lt = 0;
                        c = 0;
                    }
                    c++;
                }
                wAng += 0.8 * stp / radius;
                if (wAng > 2 * Math.PI)
                    wAng = 2 * Math.PI;
            }
            else if (Process == 7)
            {
                lt += stp * 2;
                if (lt > pL)
                {
                    isAnimating = false;
                    timer.Stop();
                    V6.OnJointValueChanged += Rot_OnRotValueChanged;
                    Process = 0;
                    lt = 0;
                    wAng = 0;
                }
                else
                {
                    MainWindowViewModel.Dxyz[0] = -stp * ta2[0];
                    MainWindowViewModel.Dxyz[1] = -stp * ta2[1];
                    MainWindowViewModel.Dxyz[2] = -stp * ta2[2];
                    MainWindowViewModel.Dxyz[3] = 0;
                    MainWindowViewModel.Dxyz[4] = 0;
                    MainWindowViewModel.Dxyz[5] = 0;
                    if (MainWindowViewModel.Jacobian[36] != 0)
                    {
                        double[] diff = JointClass6.Differential(J, new double[] { MainWindowViewModel.Dxyz[0], MainWindowViewModel.Dxyz[1], MainWindowViewModel.Dxyz[2], 0, 0, 0 });
                        MainWindowViewModel.DAngle[0] = diff[0] * 57.29578;
                        MainWindowViewModel.DAngle[1] = diff[1] * 57.29578;
                        MainWindowViewModel.DAngle[2] = diff[2] * 57.29578;
                        MainWindowViewModel.DAngle[3] = diff[3] * 57.29578;
                        MainWindowViewModel.DAngle[4] = diff[4] * 57.29578;
                        MainWindowViewModel.DAngle[5] = diff[5] * 57.29578;
                    }
                    double[] target = new double[] { TPoint6[0] - lt * ta2[0], TPoint6[1] - lt * ta2[1], TPoint6[2] - lt * ta2[2] };
                    double[] angles = JointClass6.InverseCal(tn3, to3, ta3, target, AD, MainWindowViewModel.JointAngles.ToArray());
                    ForwardKinematics(angles);
                    MainWindowViewModel.JointAngles[0] = angles[0];
                    MainWindowViewModel.JointAngles[1] = angles[1];
                    MainWindowViewModel.JointAngles[2] = angles[2];
                    MainWindowViewModel.JointAngles[3] = angles[3];
                    MainWindowViewModel.JointAngles[4] = angles[4];
                    MainWindowViewModel.JointAngles[5] = angles[5];
                }
            }
        }
        double[] TargetAngs;
        double SamplingDistance = 0.03;
        double DistanceThreshold = 2.50;
        double stp = 0.5;
        bool fstp = true;
        public double[] PGInverseKinematics(double[] target, double[] angles,ref bool tog)
        {
            double[] oldAngles = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
            angles.CopyTo(oldAngles, 0);
            double[] diff = new double[6];
            if (DistanceFromTarget(target, angles) < DistanceThreshold || fstp == false)
            {
                fstp = false;
            }

            for (int i = 0; i <= 5; i++)
            {
                double da = (TargetAngs[i] - angles[i]);
                if (da == 0)
                    continue;

                // Gradient descent
                // Update : Solution -= LearningRate * Gradient
                double gradient = PartialGradient(target, angles, i);
                if (fstp)
                    angles[i] -= LearningRate * gradient;
                else
                {
                    if ((i < 3 && Math.Abs(da) < 0.02) || (i > 2 && Math.Abs(da) < 0.1))
                        angles[i] = TargetAngs[i];
                    else
                    {
                        double dda = LearningRate * da;
                        dda = Math.Abs(dda) > 0.4 ? 0.4 * Math.Sign(dda) : dda;
                        angles[i] += dda;
                    }
                }
            }
            if ((DistanceFromTarget(target, angles) < DistanceThreshold && IsTarget(TargetAngs, angles)) || checkAngles(oldAngles, angles))
            {
                tog = true;
                return angles;
            }
            return angles;           
        }
        public bool checkAngles(double[] oldAngles, double[] angles)
        {
            for (int i = 0; i <= 5; i++)
            {
                if (oldAngles[i] != angles[i])
                    return false;
            }

            return true;
        }
        public bool IsTarget(double[] tAngles, double[] angles)
        {
            for (int i = 0; i <= 5; i++)
            {
                if (Math.Abs(tAngles[i] - angles[i]) > 0.01)
                    return false;
            }

            return true;
        }

        public double PartialGradient(double[] target, double[] angles, int i)
        {
            double angle = angles[i];
            double f_x = DistanceFromTarget(target, angles);

            angles[i] += SamplingDistance;
            double f_x_plus_d = DistanceFromTarget(target, angles);

            double gradient = (f_x_plus_d - f_x) / SamplingDistance;

            angles[i] = angle;
            return gradient;
        }


        public double DistanceFromTarget(double[] target, double[] angles)
        {
            double[] point = JointClass6.R6P(AD, new double[] { angles[0]/57.29578, angles[1] / 57.29578, angles[2] / 57.29578, angles[3] / 57.29578, angles[4] / 57.29578, angles[5] / 57.29578, });
//            double[] point = ForwardKinematics(angles);
            return Math.Sqrt(Math.Pow((point[0] - target[0]), 2.0) + Math.Pow((point[1] - target[1]), 2.0) + Math.Pow((point[2] - target[2]), 2.0));
        }
        private void rPara_OnJointValueChanged()
        {
            if (isAnimating)
                return;
        }
        JointClass6 A1, A2, A3, A4, A5, A6;
        object obj = new object();

        private void PopupBox_OnOpened(object sender, RoutedEventArgs e)
        {

        }

        private void PopupBox_OnClosed(object sender, RoutedEventArgs e)
        {

        }

        public double[] ForwardKinematics(double[] angles)
        {
            lock (obj)
            {
                F1 = new Transform3DGroup();
                R = new RotateTransform3D(new AxisAngleRotation3D(new Vector3D(0, 0, 1), angles[0]), new Point3D(0, 0, 0));
                F1.Children.Add(R);

                F2 = new Transform3DGroup();
                T = new TranslateTransform3D(0, 0, 0);
                R = new RotateTransform3D(new AxisAngleRotation3D(new Vector3D(0, 1, 0), angles[1]), MainWindowViewModel.J21);
                F2.Children.Add(T);
                F2.Children.Add(R);
                F2.Children.Add(F1);

                F3 = new Transform3DGroup();
                T = new TranslateTransform3D(0, 0, 0);
                R = new RotateTransform3D(new AxisAngleRotation3D(new Vector3D(0, 1, 0), angles[2]), MainWindowViewModel.J31);
                F3.Children.Add(T);
                F3.Children.Add(R);
                F3.Children.Add(F2);

                //as before
                F4 = new Transform3DGroup();
                T = new TranslateTransform3D(0, 0, 0); //1500, 650, 1650
                R = new RotateTransform3D(new AxisAngleRotation3D(new Vector3D(1, 0, 0), angles[3]), MainWindowViewModel.J41);
                F4.Children.Add(T);
                F4.Children.Add(R);
                F4.Children.Add(F3);

                F5 = new Transform3DGroup();
                T = new TranslateTransform3D(0, 0, 0);
                R = new RotateTransform3D(new AxisAngleRotation3D(new Vector3D(0, 1, 0), angles[4]), MainWindowViewModel.J51);
                F5.Children.Add(T);
                F5.Children.Add(R);
                F5.Children.Add(F4);

                F6 = new Transform3DGroup();
                T = new TranslateTransform3D(0, 0, 0);
                R = new RotateTransform3D(new AxisAngleRotation3D(new Vector3D(1, 0, 0), angles[5]), MainWindowViewModel.J61);
                F6.Children.Add(T);
                F6.Children.Add(R);
                F6.Children.Add(F5);

                v1.Transform = F1;
                v12.Transform = F1;
                v2.Transform = F2;
                v23.Transform = F2;
                v3.Transform = F3;
                v34.Transform = F3;
                v4.Transform = F4; 
                v45.Transform = F4; 
                v5.Transform = F5; 
                v6.Transform = F6;

                n1.Transform = F1;
                o1.Transform = F1;
                a1.Transform = F1;
                n2.Transform = F2;
                o2.Transform = F2;
                a2.Transform = F2;
                n3.Transform = F3;
                o3.Transform = F3;
                a3.Transform = F3;
                n4.Transform = F4;
                o4.Transform = F4;
                a4.Transform = F4;
                n5.Transform = F5;
                o5.Transform = F5;
                a5.Transform = F5;
                n6.Transform = F6;
                o6.Transform = F6;
                a6.Transform = F6;
                v7.Transform = F6;

                double[] Ang = new double[6] { angles[0] / 57.29578, angles[1] / 57.29578, angles[2] / 57.29578, angles[3] / 57.29578, angles[4] / 57.29578, angles[5] / 57.29578 };
                r6p = JointClass6.R6P(AD, Ang);
                MainWindowViewModel.EndP[0] = r6p[0];
                MainWindowViewModel.EndP[1] = r6p[1];
                MainWindowViewModel.EndP[2] = r6p[2];
                r6n = JointClass6.R6N(Ang);
                MainWindowViewModel.EndN[0] = r6n[0];
                MainWindowViewModel.EndN[1] = r6n[1];
                MainWindowViewModel.EndN[2] = r6n[2];
                r6o = JointClass6.R6O(Ang);
                MainWindowViewModel.EndO[0] = r6o[0];
                MainWindowViewModel.EndO[1] = r6o[1];
                MainWindowViewModel.EndO[2] = r6o[2];
                r6a = JointClass6.R6A(Ang);
                MainWindowViewModel.EndA[0] = r6a[0];
                MainWindowViewModel.EndA[1] = r6a[1];
                MainWindowViewModel.EndA[2] = r6a[2];

                r5p = JointClass6.R5P(AD, Ang);
                MainWindowViewModel.J5P[0] = r5p[0];
                MainWindowViewModel.J5P[1] = r5p[1];
                MainWindowViewModel.J5P[2] = r5p[2];
                r5n = JointClass6.R5N(Ang);
                MainWindowViewModel.J5N[0] = r5n[0];
                MainWindowViewModel.J5N[1] = r5n[1];
                MainWindowViewModel.J5N[2] = r5n[2];
                r5o = JointClass6.R5O(Ang);
                MainWindowViewModel.J5O[0] = r5o[0];
                MainWindowViewModel.J5O[1] = r5o[1];
                MainWindowViewModel.J5O[2] = r5o[2];
                r5a = JointClass6.R5A(Ang);
                MainWindowViewModel.J5A[0] = r5a[0];
                MainWindowViewModel.J5A[1] = r5a[1];
                MainWindowViewModel.J5A[2] = r5a[2];


                r4p = JointClass6.R4P(AD, Ang);
                MainWindowViewModel.J4P[0] = r4p[0];
                MainWindowViewModel.J4P[1] = r4p[1];
                MainWindowViewModel.J4P[2] = r4p[2];
                r4n = JointClass6.R4N(Ang);
                MainWindowViewModel.J4N[0] = r4n[0];
                MainWindowViewModel.J4N[1] = r4n[1];
                MainWindowViewModel.J4N[2] = r4n[2];
                r4o = JointClass6.R4O(Ang);
                MainWindowViewModel.J4O[0] = r4o[0];
                MainWindowViewModel.J4O[1] = r4o[1];
                MainWindowViewModel.J4O[2] = r4o[2];
                r4a = JointClass6.R4A(Ang);
                MainWindowViewModel.J4A[0] = r4a[0];
                MainWindowViewModel.J4A[1] = r4a[1];
                MainWindowViewModel.J4A[2] = r4a[2];

                r3p = JointClass6.R3P(AD, Ang);
                MainWindowViewModel.J3P[0] = r3p[0];
                MainWindowViewModel.J3P[1] = r3p[1];
                MainWindowViewModel.J3P[2] = r3p[2];
                r3n = JointClass6.R3N(Ang);
                MainWindowViewModel.J3N[0] = r3n[0];
                MainWindowViewModel.J3N[1] = r3n[1];
                MainWindowViewModel.J3N[2] = r3n[2];
                r3o = JointClass6.R3O(Ang);
                MainWindowViewModel.J3O[0] = r3o[0];
                MainWindowViewModel.J3O[1] = r3o[1];
                MainWindowViewModel.J3O[2] = r3o[2];
                r3a = JointClass6.R3A(Ang);
                MainWindowViewModel.J3A[0] = r3a[0];
                MainWindowViewModel.J3A[1] = r3a[1];
                MainWindowViewModel.J3A[2] = r3a[2];

                r2p = JointClass6.R2P(AD, Ang);
                MainWindowViewModel.J2P[0] = r2p[0];
                MainWindowViewModel.J2P[1] = r2p[1];
                MainWindowViewModel.J2P[2] = r2p[2];
                r2n = JointClass6.R2N(Ang);
                MainWindowViewModel.J2N[0] = r2n[0];
                MainWindowViewModel.J2N[1] = r2n[1];
                MainWindowViewModel.J2N[2] = r2n[2];
                r2o = JointClass6.R2O(Ang);
                MainWindowViewModel.J2O[0] = r2o[0];
                MainWindowViewModel.J2O[1] = r2o[1];
                MainWindowViewModel.J2O[2] = r2o[2];
                r2a = JointClass6.R2A(Ang);
                MainWindowViewModel.J2A[0] = r2a[0];
                MainWindowViewModel.J2A[1] = r2a[1];
                MainWindowViewModel.J2A[2] = r2a[2];

                r1p = JointClass6.R1P(AD, Ang);
                MainWindowViewModel.J1P[0] = r1p[0];
                MainWindowViewModel.J1P[1] = r1p[1];
                MainWindowViewModel.J1P[2] = r1p[2];
                r1n = JointClass6.R1N(Ang);
                MainWindowViewModel.J1N[0] = r1n[0];
                MainWindowViewModel.J1N[1] = r1n[1];
                MainWindowViewModel.J1N[2] = r1n[2];
                r1o = JointClass6.R1O(Ang);
                MainWindowViewModel.J1O[0] = r1o[0];
                MainWindowViewModel.J1O[1] = r1o[1];
                MainWindowViewModel.J1O[2] = r1o[2];
                r1a = JointClass6.R1A(Ang);
                MainWindowViewModel.J1A[0] = r1a[0];
                MainWindowViewModel.J1A[1] = r1a[1];
                MainWindowViewModel.J1A[2] = r1a[2];

                iangs = JointClass6.InverseCal(r6n, r6o, r6a, r6p, AD, iangs);
                MainWindowViewModel.IJointAngles[0] = iangs[0];
                MainWindowViewModel.IJointAngles[1] = iangs[1];
                MainWindowViewModel.IJointAngles[2] = iangs[2];
                MainWindowViewModel.IJointAngles[3] = iangs[3];
                MainWindowViewModel.IJointAngles[4] = iangs[4];
                MainWindowViewModel.IJointAngles[5] = iangs[5];
                J = JointClass6.Jacobian(AD, Ang);
                for (int i = 0; i < 6; i++)
                    for (int j = 0; j < 6; j++)
                        MainWindowViewModel.Jacobian[i * 6 + j] = J[i, j];
                MainWindowViewModel.Jacobian[36] = JointClass6.Det(J);
                A1.CurAngle= Ang[0];
                A2.CurAngle = Ang[1];
                A3.CurAngle = Ang[2];
                A4.CurAngle = Ang[3];
                A5.CurAngle = Ang[4];
                A6.CurAngle = Ang[5];

                Matrix4x4 t1 = A1.T;
                Matrix4x4 t2 = t1 * A2.T;
                Matrix4x4 t3 = t2 * A3.T;
                Matrix4x4 t4 = t3 * A4.T;
                Matrix4x4 t5 = t4 * A5.T;
                Matrix4x4 t6 = t5 * A6.T;

                float x = 300;
                float y = 400;
                float z = 500;

                double rotX = 30;
                double rotY = 45;
                double rotZ = 150;

                float cx = (float)Math.Cos(rotX / 57.29578);
                float sx = (float)Math.Sin(rotX / 57.29578);
                float cy = (float)Math.Cos(rotY / 57.29578);
                float sy = (float)Math.Sin(rotY / 57.29578);
                float cz = (float)Math.Cos(rotZ / 57.29578);
                float sz = (float)Math.Sin(rotZ / 57.29578);

                float px = 30;
                float py = 200;
                float pz = 20;
                float nx = -0.7071f;
                float ny = 0;
                float nz = 0.7071f;
                float ox = 0;
                float oy = 1;
                float oz = 0;
                float ax = -0.7071f;
                float ay = 0;
                float az = -0.7071f;

                Matrix4x4 rx = new Matrix4x4(1, 0, 0, 0, 0, cx, -sx, 0, 0, sx, cx, 0, 0, 0, 0, 1);
                Matrix4x4 ry = new Matrix4x4(cy, 0, sy, 0, 0, 1, 0, 0, -sy, 0, cy, 0, 0, 0, 0, 1);
                Matrix4x4 rz = new Matrix4x4(cz, -sz, 0, 0, sz, cz, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
                Matrix4x4 txyz = new Matrix4x4(1, 0, 0, x, 0, 1, 0, y, 0, 0, 1, z, 0, 0, 0, 1);
                Matrix4x4 m4 = txyz * rz * ry * rx;

                double dx = m4.M11 * px + m4.M12 * py + m4.M13 * pz+m4.M14;
                double dy = m4.M21 * px + m4.M22 * py + m4.M23 * pz + m4.M24;
                double dz = m4.M31 * px + m4.M32 * py + m4.M33 * pz + m4.M34;

                rx = new Matrix4x4(1, 0, 0, 0, 0, cx, sx, 0, 0, -sx, cx, 0, 0, 0, 0, 1);
                ry = new Matrix4x4(cy, 0, -sy, 0, 0, 1, 0, 0, sy, 0, cy, 0, 0, 0, 0, 1);
                rz = new Matrix4x4(cz, sz, 0, 0, -sz, cz, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
                txyz = new Matrix4x4(1, 0, 0, -x, 0, 1, 0, -y, 0, 0, 1, -z, 0, 0, 0, 1);

                m4 = rx * ry * rz * txyz;

                double fx = m4.M11 * dx + m4.M12 * dy + m4.M13 * dz + m4.M14;
                double fy = m4.M21 * dx + m4.M22 * dy + m4.M23 * dz + m4.M24;
                double fz = m4.M31 * dx + m4.M32 * dy + m4.M33 * dz + m4.M34;


                double[] tmpM = { 1, 0.5, 1, 0.5, 0.5, 1 };
                /*
                Stopwatch watch = Stopwatch.StartNew();
                double[,] Jacobi5 = JointClass6.Jacobian5(AD, Ang);
                Jacobi = JointClass6.Jacobian(AD, Ang);
                Console.WriteLine("Jacobian test took: " + watch.ElapsedMilliseconds + " ms.");

                watch = Stopwatch.StartNew();
                var luJ = Utilities.DoubleArrayExtensions.LuDecomposition(Jacobi);
                Console.WriteLine("LUD test took: " + watch.ElapsedMilliseconds + " ms.");

                watch = Stopwatch.StartNew();
                double[,] IJacobi5 = Utilities.DoubleArrayExtensions.LuInverse(luJ);
                Console.WriteLine("IJacobi5 test took: " + watch.ElapsedMilliseconds + " ms.");

                watch = Stopwatch.StartNew();
                double[,] IJacobi52 = Utilities.DoubleArrayExtensions.LuInverseUnsafe(luJ);
                Console.WriteLine("IJacobi52 test took: " + watch.ElapsedMilliseconds + " ms.");
                double[] tm = IJacobi52.Dot(tmpM);

                watch = Stopwatch.StartNew();
                double[,] IJacobi53 = EigenWrapper.MatrixMath.InvertMatrix(Jacobi5);
                IJacobi = EigenWrapper.MatrixMath.InvertMatrix(Jacobi);
                Console.WriteLine("IJacobi53 test took: " + watch.ElapsedMilliseconds + " ms.");

                watch = Stopwatch.StartNew();
                //转置后逆
                //double[,] IJacobi54 = EigenWrapper.MatrixMath.InvertMatrix(Jacobi5,true);
                //Console.WriteLine("IJacobi54 test took: " + watch.ElapsedMilliseconds + " ms.");
                watch = Stopwatch.StartNew();
                double[,] IJacobi55 = Utilities.DoubleArrayExtensions.InverseMatrix(Jacobi);
                Console.WriteLine("IJacobi55 test took: " + watch.ElapsedMilliseconds + " ms.");
                double[] tm2 = IJacobi55.Dot(tmpM);
                double[] tm3 = JointClass6.Differential(AD, Ang, tmpM);

                //watch = Stopwatch.StartNew();
                //转置后逆
                //var tmpA = Utilities.DoubleArrayExtensions.Transpose(Jacobi5);
                //Console.WriteLine("tmpA test took: " + watch.ElapsedMilliseconds + " ms.");
                //watch = Stopwatch.StartNew();
                //double[,] IJacobi56 = Utilities.DoubleArrayExtensions.InverseMatrix(tmpA);
                //Console.WriteLine("IJacobi56 test took: " + watch.ElapsedMilliseconds + " ms.");


                r6n = JointClass6.R6N(Ang);
                r6o = JointClass6.R6O(Ang);
                r6a = JointClass6.R5A(Ang);
                iangs = JointClass6.InverseCal(r6n, r6o, r6a, r6p, AD, iangs);
                MainWindowViewModel.IJointValue[0] = iangs[0];
                MainWindowViewModel.IJointValue[1] = iangs[1];
                MainWindowViewModel.IJointValue[2] = iangs[2];
                MainWindowViewModel.IJointValue[3] = iangs[3];
                MainWindowViewModel.IJointValue[4] = iangs[4];
                MainWindowViewModel.IJointValue[5] = iangs[5];

                MainWindowViewModel.EndPos[0] = r6p[0];
                MainWindowViewModel.EndPos[1] = r6p[1];
                MainWindowViewModel.EndPos[2] = r6p[2] + 450;

                double[] euler = JointClass6.VectorToEuler(r6n, r6o, r6a);
                MainWindowViewModel.EndEAng[0] = euler[0];
                MainWindowViewModel.EndEAng[1] = euler[1];
                MainWindowViewModel.EndEAng[2] = euler[2];
                double[,] matrix = JointClass6.EulerToVector(euler);*/

            }
            return r6p;
        }
        double[] r6n, r6o, r6a, r6p, r5n, r5o, r5a, r5p, r4n, r4o, r4a, r4p, r3n, r3o, r3a, r3p, r2n, r2o, r2a, r2p, r1n, r1o, r1a, r1p, iangs;
        double[,] J;

        double[] CurAngles = new double[6];
        private void Rot_OnRotValueChanged()
        {
            MainWindowViewModel.JointAngles.CopyTo(CurAngles, 0);
            ForwardKinematics(CurAngles);
        }
        public double[][] AD => new double[6][] { new double[2] { MainWindowViewModel.JointLength[0], 0 }, new double[2] { MainWindowViewModel.JointLength[1], 0 }, new double[2] { MainWindowViewModel.JointLength[2], 0 }, new double[2] { 0, MainWindowViewModel.JointLength[3] }, new double[2] { 0, 0 }, new double[2] { MainWindowViewModel.JointLength[5], MainWindowViewModel.JointLength[4]+ MainWindowViewModel.JointLength[6] } };
    }
}
